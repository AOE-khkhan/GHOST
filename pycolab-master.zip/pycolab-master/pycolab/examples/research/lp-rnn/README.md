# Tasks for LP-RNN

Three tasks that are featured in an upcoming paper that discusses a memory
architecture for reinforcement learning (more info available soon). Refer to the
top-level docstrings inside each `.py` file for details.

Note: These files are "research code" and should not necessarily be considered
good examples of pycolab programs (see the README for the parent directory).
Additionally, while pycolab is compatible with recent versions of python 2.7 and
python 3, these files have only been used with python 2.7. Python 3
compatibility has not been tested.
